# `@second-claude/core`

Host-neutral quality contracts and pure policy decisions shared by Second Claude integrations.

The package ships checked-in ESM and TypeScript declarations. Plugin startup imports `dist/index.js` directly and never invokes a package manager or compiler. Persistence, environment access, hook input, MCP transport, and execution remain adapter responsibilities.

```js
import {
  classifyQualityProfile,
  evaluateGate,
  validatePlan
} from "@second-claude/core";
```

The shared cross-host fixture is exported at `@second-claude/core/fixtures/quality-contract.json`.

Completion validation takes a host-supplied current artifact hash, producer identity, and reviewer-availability context. Every artifact and reviewer evidence item must be attributed to that producer. Non-minimal profiles cannot complete without current, passing, independent reviewer evidence and completed `critic` and `promote` stages. A reviewer result proves approval only when it is exactly `"pass"` or `true`; `"warning"`, numeric scores, and other results remain unproven.

Core evaluates this contract; it does not authenticate the host or manufacture provenance. The standalone Claude/Codex adapter's native/MMBridge records are same-UID, locally HMAC-tagged diagnostic telemetry: code running as that user can read the key and forge a record, so the adapter must report independent reviewer and provider availability as false and remains `UNPROVEN` wherever independence is required. The HMAC detects stale or accidentally altered local records; it is not caller-inaccessible proof. UncleCode's in-process runtime may supply authoritative host-owned provider trace evidence after establishing identity outside worker-controlled artifacts.

Evolution validation remains host-neutral: the host supplies the current candidate artifact hash, resolves canonical branch/worktree existence and identity, then passes an `EvolutionIsolationAttestation`, an explicit evaluation timestamp, and a maximum attestation age. Core requires nonblank candidate, creator, evaluator, and held-out benchmark identities; finite baseline/candidate scores; a strict held-out score improvement; and current, passing reviewer evidence attributed to the candidate creator. It rejects self-review. Timestamps use canonical UTC ISO 8601 with milliseconds (`YYYY-MM-DDTHH:mm:ss.sssZ`), and proof remains fresh through the inclusive maximum-age boundary. Core binds isolation proof exactly to the candidate, branch, and worktree and rejects incomplete, future, stale, mismatched, nonexistent, base/current, or creator/evaluator-supplied isolation evidence without reading the filesystem or consulting a clock.
